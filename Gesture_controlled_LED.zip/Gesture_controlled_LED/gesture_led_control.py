import cv2
import mediapipe as mp
import serial
import time

arduino = serial.Serial('/dev/tty.usbmodem101', 9600, timeout=1)
time.sleep(2)

mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
cap = cv2.VideoCapture(0)

finger_tips = [20, 16, 12, 8]  # Pinky, Ring, Middle, Index (skip thumb for now)
finger_bottom = [17, 14, 10, 6]

print("System ready! Raise fingers to control LEDs.")

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    result = hands.process(rgb)
    finger_states = [0, 0, 0, 0, 0]

    if result.multi_hand_landmarks:
        for hand_landmarks, handedness in zip(result.multi_hand_landmarks, result.multi_handedness):
            label = handedness.classification[0].label  # "Left" or "Right"

            # Check all fingers except thumb
            for i in range(4):
                tip_y = hand_landmarks.landmark[finger_tips[i]].y
                bottom_y = hand_landmarks.landmark[finger_bottom[i]].y
                finger_states[i] = 1 if tip_y < bottom_y else 0

            # Thumb logic: depends on hand side
            if label == "Left":
                if hand_landmarks.landmark[4].x > hand_landmarks.landmark[3].x:
                    finger_states[4] = 1
                else:
                    finger_states[4] = 0
            else:
                if hand_landmarks.landmark[4].x < hand_landmarks.landmark[3].x:
                    finger_states[4] = 1
                else:
                    finger_states[4] = 0

            mp_drawing.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

        command = " ".join(str(s) for s in finger_states) + "\n"
        arduino.write(command.encode('utf-8'))
        print("Sent:", command.strip())

    cv2.imshow("Gesture LED Control", frame)
    if cv2.waitKey(1) & 0xFF == 27:
        break

cap.release()
arduino.close()
cv2.destroyAllWindows()